

public abstract class FiguraGeometrica {
    public abstract double calcularVolumen();
    public abstract double calcularSuperficie();
}
