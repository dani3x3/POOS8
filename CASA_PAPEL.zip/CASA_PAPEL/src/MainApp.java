import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainApp extends JFrame {
    private JTextField longitudCaja;
    private JTextField anchuraCaja;
    private JTextField alturaCaja;
    private JTextField radioCilindro;
    private JTextField alturaCilindro;
    private JTextField radioEsfera;
    private JTextArea resultadoArea;

    public MainApp() {
        setTitle("Calculadora de Figuras Geométricas");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(10, 2));

        // Caja
        add(new JLabel("Caja - Longitud (cm):"));
        longitudCaja = new JTextField();
        add(longitudCaja);

        add(new JLabel("Caja - Anchura (cm):"));
        anchuraCaja = new JTextField();
        add(anchuraCaja);

        add(new JLabel("Caja - Altura (cm):"));
        alturaCaja = new JTextField();
        add(alturaCaja);

        // Cilindro
        add(new JLabel("Cilindro - Radio (cm):"));
        radioCilindro = new JTextField();
        add(radioCilindro);

        add(new JLabel("Cilindro - Altura (cm):"));
        alturaCilindro = new JTextField();
        add(alturaCilindro);

        // Esfera
        add(new JLabel("Esfera - Radio (cm):"));
        radioEsfera = new JTextField();
        add(radioEsfera);

        // Botón para calcular
        JButton calcularBtn = new JButton("Calcular");
        add(calcularBtn);

        // Área de resultados
        resultadoArea = new JTextArea();
        resultadoArea.setEditable(false);
        add(new JScrollPane(resultadoArea));

        calcularBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcularResultados();
            }
        });
    }

    private void calcularResultados() {
        StringBuilder resultados = new StringBuilder();

        try {
            double longitud = Double.parseDouble(longitudCaja.getText());
            double anchura = Double.parseDouble(anchuraCaja.getText());
            double altura = Double.parseDouble(alturaCaja.getText());
            Caja caja = new Caja(longitud, anchura, altura);
            resultados.append("Caja:\n");
            resultados.append("Volumen: ").append(caja.calcularVolumen()).append(" cm³\n");
            resultados.append("Superficie: ").append(caja.calcularSuperficie()).append(" cm²\n\n");
        } catch (NumberFormatException e) {
            resultados.append("Datos de la caja no válidos\n\n");
        }

        try {
            double radioCil = Double.parseDouble(radioCilindro.getText());
            double alturaCil = Double.parseDouble(alturaCilindro.getText());
            Cilindro cilindro = new Cilindro(radioCil, alturaCil);
            resultados.append("Cilindro:\n");
            resultados.append("Volumen: ").append(cilindro.calcularVolumen()).append(" cm³\n");
            resultados.append("Superficie: ").append(cilindro.calcularSuperficie()).append(" cm²\n\n");
        } catch (NumberFormatException e) {
            resultados.append("Datos del cilindro no válidos\n\n");
        }

        try {
            double radioEsp = Double.parseDouble(radioEsfera.getText());
            Esfera esfera = new Esfera(radioEsp);
            resultados.append("Esfera:\n");
            resultados.append("Volumen: ").append(esfera.calcularVolumen()).append(" cm³\n");
            resultados.append("Superficie: ").append(esfera.calcularSuperficie()).append(" cm²\n\n");
        } catch (NumberFormatException e) {
            resultados.append("Datos de la esfera no válidos\n\n");
        }

        resultadoArea.setText(resultados.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainApp().setVisible(true);
            }
        });
    }
}
