

public class Caja extends FiguraGeometrica {
    private double longitud;
    private double anchura;
    private double altura;

    public Caja(double longitud, double anchura, double altura) {
        this.longitud = longitud;
        this.anchura = anchura;
        this.altura = altura;
    }

    @Override
    public double calcularVolumen() {
        return longitud * anchura * altura;
    }

    @Override
    public double calcularSuperficie() {
        return 2 * (longitud * anchura + longitud * altura + anchura * altura);
    }
}
